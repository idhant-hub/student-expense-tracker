# Student Expense Tracker — Project Report

## 1. Introduction

Managing personal expenses is an important skill for students. The Student Expense Tracker is a Python application designed to record, organize, search, and summarize daily expenses.

## 2. Problem Statement

Students often make small daily payments for food, transportation, education, shopping, and other activities. Without proper records, it becomes difficult to understand where money is being spent. This project provides a simple digital solution.

## 3. Objectives

1. Record daily expenses.
2. Store expense information permanently.
3. Display all recorded transactions.
4. Search expenses by category.
5. Calculate total expenditure.
6. Generate category-wise summaries.
7. Allow users to delete incorrect records.

## 4. Methodology

The application uses a menu-driven command-line interface. Expense records are stored in a CSV file. The `ExpenseTracker` class handles data operations, while `main.py` handles user interaction.

## 5. Modules

### Main Module
Provides the menu and collects input from the user.

### Expense Tracker Module
Provides functions for adding, reading, deleting, filtering, and summarizing expenses.

### CSV Data Module
Stores expense records in a structured format.

## 6. Advantages

- Easy to use
- Lightweight
- No external database required
- Data remains available after the program closes
- Suitable for beginners learning Python

## 7. Future Scope

The project can be extended with a GUI, SQLite database, charts, budget notifications, authentication, and automated reports.

## 8. Conclusion

The Student Expense Tracker demonstrates how Python can be used to solve a practical everyday problem. It combines file handling, object-oriented programming, input validation, and data processing in one complete application.
